import math

#-----------------------Zad 1--------------------
def sum_even_numbers(numbers):
    if not isinstance(numbers, list):
        raise TypeError("Input must be a list")
    
    try:
        return sum(num for num in numbers if isinstance(num, (int, float)) and num % 2 == 0)
    except TypeError:
        raise ValueError("List must contain only numbers")

sample_list = [1, 2, 3, 4, 5, 6, 7.0, 8, 10]
print(sum_even_numbers(sample_list))


#------------------- Zad 2 ----------------------
class Book:
    def __init__(self, title: str, author: str, publication_year: int):
        self._title = title
        self._author = author
        self._publication_year = publication_year

    def get_title(self) -> str:
        return self._title

    def get_author(self) -> str:
        return self._author

    def get_publication_year(self) -> int:
        return self._publication_year

    def set_title(self, title: str):
        self._title = title

    def set_author(self, author: str):
        self._author = author

    def set_publication_year(self, publication_year: int):
        if not isinstance(publication_year, int) or publication_year < 0:
            raise ValueError("Publication year must be a positive integer")
        
        self._publication_year = publication_year

    def __str__(self):
        return f"{self._title} by {self._author}, published in {self._publication_year}"

book = Book("1984", "George Orwell", 1949)
print(book)

print("Title:", book.get_title())
print("Author:", book.get_author())
print("Publication Year:", book.get_publication_year())

book.set_title("Animal Farm")
book.set_author("George Orwell")
book.set_publication_year(1945)
print(book)


#-------------------- Zad 4 --------------------
def calculate_average(numbers: list) -> float:
    if not numbers:
        raise ValueError("The list cannot be empty")
    
    if not all(isinstance(num, (int, float)) for num in numbers):
        raise TypeError("All elements in the list must be numbers")
    
    return sum(numbers) / len(numbers)

numbers = [10, 20, 30, 40, 50]
try:
    average = calculate_average(numbers)
    print(f"Average value: {average}")
    
except (ValueError, TypeError) as e:
    print(f"Error: {e}")


#--------------------Zad 6---------------------
def fibonacci(n: int) -> int:
    if n < 0:
        raise ValueError("Input must be a non-negative integer")
    
    if n == 0:
        return 0
    elif n == 1:
        return 1
    
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

print(fibonacci(10))


#--------------------Zad 8---------------------
class Point3D:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def add(self, other_point):
        new_x = self.x + other_point.x
        new_y = self.y + other_point.y
        new_z = self.z + other_point.z
        return Point3D(new_x, new_y, new_z)

    def distance_to(self, other_point):
        distance = math.sqrt((self.x - other_point.x) ** 2 +
                                (self.y - other_point.y) ** 2 +
                                (self.z - other_point.z) ** 2)
        return distance

point1 = Point3D(1, 2, 3)
point2 = Point3D(4, 5, 6)
point3 = Point3D(7, 8, 9)

result_point = point1.add(point2)
print(f"Added Point: ({result_point.x}, {result_point.y}, {result_point.z})")

distance1_2 = point1.distance_to(point2)
distance2_3 = point2.distance_to(point3)

print(f"Distance between point1 and point2: {distance1_2}")
print(f"Distance between point2 and point3: {distance2_3}")


#------------------Zad 10------------------------
def is_palindrome(text):
    cleaned_text = ''.join(char.lower() for char in text if char.isalnum())
    return cleaned_text == cleaned_text[::-1] 

print(is_palindrome("A man, a plan, a canal, Panama"))
