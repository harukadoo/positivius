from modules import Book
from modules import calculate_average
from modules import fibonacci
from modules import Point3D

def main():
    #-----------------------Zad 3--------------------
    book1 = Book("1984", "George Orwell", 1949)
    book2 = Book("To Kill a Mockingbird", "Harper Lee", 1960)
    book3 = Book("The Great Gatsby", "F. Scott Fitzgerald", 1925)

    books = [book1, book2, book3]
    for book in books:
        print(book)


    #-------------------- Zad 5 ----------------------
    numbers = [10, 20, 30, 40, 50]

    try:
        average = calculate_average(numbers)
        print(f"Average value: {average}")

    except (ValueError, TypeError) as e:
        print(f"Error: {e}")


    #-------------------Zad 7 -----------------
    def generate_fibonacci_sequence(n: int) -> list:
        if n < 1:
            raise ValueError("Input must be a positive integer")
        
        return [fibonacci(i) for i in range(n)]

    n = 10
    try:
        sequence = generate_fibonacci_sequence(n)
        print(f"First {n} Fibonacci numbers: {sequence}")
        
    except ValueError as e:
        print(f"Error: {e}")


    #--------------------Zad 9---------------------
    point1 = Point3D(1, 2, 3)
    point2 = Point3D(4, 5, 6)
    point3 = Point3D(7, 8, 9)

    result_point = point1.add(point2)
    print(f"Added Point: ({result_point.x}, {result_point.y}, {result_point.z})")

    distance1_2 = point1.distance_to(point2)
    distance2_3 = point2.distance_to(point3)

    print(f"Distance between point1 and point2: {distance1_2}")
    print(f"Distance between point2 and point3: {distance2_3}")

if __name__ == "__main__":
    main()
